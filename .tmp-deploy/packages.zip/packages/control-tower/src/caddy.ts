import { mkdir, writeFile } from "node:fs/promises";
import http from "node:http";
import https from "node:https";
import path from "node:path";
import type { CaddyRouteConfig, MetadataSnapshot } from "./types.js";

export interface CaddyPublishOptions {
  adminOrigin: string;
  listenAddress: string;
}

export function buildCaddyRouteConfig(
  snapshot: MetadataSnapshot,
  options: CaddyPublishOptions
): CaddyRouteConfig {
  const routes = snapshot.routes.map((route) => {
    const upstream = new URL(route.authTarget);
    const dial = upstream.port ? `${upstream.hostname}:${upstream.port}` : upstream.hostname;
    const handle: Record<string, unknown>[] = [];

    if (upstream.pathname && upstream.pathname !== "/") {
      handle.push({
        handler: "rewrite",
        strip_path_prefix: upstream.pathname
      });
    }

    handle.push({
      handler: "reverse_proxy",
      upstreams: [{ dial }]
    });

    return {
      match: [{ host: [route.subdomain] }],
      handle
    };
  });

  return {
    adminOrigin: options.adminOrigin,
    routeCount: routes.length,
    config: {
      admin: {
        listen: options.adminOrigin.replace(/^https?:\/\//, "")
      },
      apps: {
        http: {
          servers: {
            control_tower: {
              listen: [options.listenAddress],
              automatic_https: {
                disable: true
              },
              routes
            }
          }
        }
      }
    }
  };
}

export async function writeCaddyConfigFile(filePath: string, config: CaddyRouteConfig): Promise<string> {
  await mkdir(path.dirname(filePath), { recursive: true });
  await writeFile(filePath, JSON.stringify(config.config, null, 2) + "\n", "utf8");
  return filePath;
}

export async function publishCaddyConfig(config: CaddyRouteConfig): Promise<void> {
  const target = new URL("/load", config.adminOrigin);
  const payload = JSON.stringify(config.config);
  const transport = target.protocol === "https:" ? https : http;

  await new Promise<void>((resolve, reject) => {
    const request = transport.request(
      {
        method: "POST",
        protocol: target.protocol,
        hostname: target.hostname,
        port: target.port,
        path: `${target.pathname}${target.search}`,
        headers: {
          "Content-Type": "application/json",
          "Content-Length": String(Buffer.byteLength(payload))
        }
      },
      (response) => {
        let body = "";
        response.setEncoding("utf8");
        response.on("data", (chunk) => {
          body += chunk;
        });
        response.on("end", () => {
          const statusCode = response.statusCode ?? 500;
          if (statusCode >= 200 && statusCode < 300) {
            resolve();
            return;
          }
          reject(new Error(`Caddy admin API returned ${statusCode}: ${body || response.statusMessage}`));
        });
      }
    );

    request.on("error", reject);
    request.write(payload);
    request.end();
  });
}
