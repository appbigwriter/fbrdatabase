import { exec, execFile } from "node:child_process";
import { promisify } from "node:util";
import { mkdir, readFile, writeFile } from "node:fs/promises";

const execFileAsync = promisify(execFile);
const execAsync = promisify(exec);
const root = process.cwd();
const nodeBin = process.execPath;
const npmBin = process.platform === "win32" ? "npm.cmd" : "npm";

const env = sanitizeEnv({
  ...process.env,
  CONTROL_TOWER_MODE: "real",
  CONTROL_TOWER_METADATA_DATABASE_URL: "postgres://postgres:postgres@127.0.0.1:5433/control_tower_meta",
  CONTROL_TOWER_SUPER_POSTGRES_URL: "postgres://postgres:postgres@127.0.0.1:5433/postgres",
  CONTROL_TOWER_PROJECT_DB_HOST: "postgres://127.0.0.1:5433",
  CONTROL_TOWER_DOCKER_NETWORK_NAME: "control-tower-net",
  CONTROL_TOWER_DOCKER_HOST_GATEWAY_NAME: "host.docker.internal",
  CONTROL_TOWER_DOCKER_PUBLISHED_PORT_BASE: "11000",
  CONTROL_TOWER_GOTRUE_IMAGE: "supabase/auth:v2.192.0",
  CONTROL_TOWER_GOTRUE_DB_URL_TEMPLATE:
    "postgres://postgres:postgres@postgres:5432/{databaseName}?sslmode=disable",
  CONTROL_TOWER_GOTRUE_SITE_URL_TEMPLATE: "http://{subdomain}:8080",
  CONTROL_TOWER_GOTRUE_EXTERNAL_URL_TEMPLATE: "http://{subdomain}:8080/auth",
  CONTROL_TOWER_CADDY_ADMIN_ORIGIN: "http://127.0.0.1:2019",
  CONTROL_TOWER_CADDY_LISTEN_ADDRESS: ":8080"
});

await run(npmBin, ["run", "build"]);
await run("docker", ["compose", "-f", "docker-compose.real.yml", "up", "-d"]);
await waitForMetadata();
await run(nodeBin, ["dist/bin/control-tower.js", "metadata", "migrate"], { env });
const manifestPath = await createSmokeManifest();
const smoke = await run(nodeBin, ["dist/bin/control-tower.js", "smoke", "run", manifestPath], {
  env
});
try {
  await run(nodeBin, ["dist/bin/control-tower.js", "routes", "publish"], { env });
} catch (error) {
  const message = error instanceof Error ? error.message : String(error);
  if (!message.includes("socket hang up")) {
    throw error;
  }
  await sleep(1000);
}

const smokeJson = JSON.parse(smoke.stdout.trim());
const manifest = JSON.parse(await readFile(manifestPath, "utf8"));
const response = await fetch("http://127.0.0.1:8080/health", {
  headers: { Host: manifest.subdomain }
});

console.log(
  JSON.stringify(
    {
      smoke: smokeJson,
      caddyStatus: response.status,
      caddyOk: response.ok
    },
    null,
    2
  )
);

async function waitForMetadata() {
  let lastError = "";
  for (let attempt = 1; attempt <= 30; attempt += 1) {
    try {
      await run(nodeBin, ["dist/bin/control-tower.js", "metadata", "migrate"], { env });
      return;
    } catch (error) {
      lastError = error instanceof Error ? error.message : String(error);
      await sleep(2000);
    }
  }
  throw new Error(`Metadata database did not become ready: ${lastError}`);
}

async function run(command, args, options = {}) {
  if (process.platform === "win32") {
    const escaped = [command, ...args].map(quoteForCmd).join(" ");
    return execAsync(escaped, {
      cwd: root,
      windowsHide: true,
      ...options
    });
  }

  return execFileAsync(command, args, {
    cwd: root,
    windowsHide: true,
    ...options
  });
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function sanitizeEnv(input) {
  return Object.fromEntries(Object.entries(input).filter(([, value]) => value !== undefined));
}

async function createSmokeManifest() {
  const template = JSON.parse(await readFile("examples/project-manifest.json", "utf8"));
  const suffix = Date.now().toString(36);
  const manifest = {
    ...template,
    name: `${template.name} ${suffix}`,
    slug: `revista-control-tower-${suffix}`,
    subdomain: `revista-${suffix}.lab.fbr.news`,
    databaseName: `revista_control_tower_${suffix}`
  };
  const manifestPath = ".data/smoke/project-manifest.real.json";
  await mkdir(".data/smoke", { recursive: true });
  await writeFile(manifestPath, JSON.stringify(manifest, null, 2) + "\n", "utf8");
  return manifestPath;
}

function quoteForCmd(value) {
  if (/^[A-Za-z0-9_./:=+\\-]+$/.test(value)) {
    return value;
  }
  return `"${String(value).replace(/"/g, '""')}"`;
}
